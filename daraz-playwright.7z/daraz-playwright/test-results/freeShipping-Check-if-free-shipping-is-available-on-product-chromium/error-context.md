# Test info

- Name: Check if free shipping is available on product
- Location: C:\Users\Dell e6430\Documents\daraz-playwright\tests\freeShipping.spec.js:4:5

# Error details

```
Error: page.waitForSelector: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('div._9xWFp') to be visible

    at ResultsPage.applyFilters (C:\Users\Dell e6430\Documents\daraz-playwright\pages\resultsPage.js:19:25)
    at C:\Users\Dell e6430\Documents\daraz-playwright\tests\freeShipping.spec.js:6:5
```

# Test source

```ts
   1 | exports.ResultsPage = class ResultsPage {
   2 |     constructor(page) {
   3 |         this.page = page;
   4 |         this.brandFilter = 'div.y9-OE a label span:nth-child(2)';
   5 |         this.minPrice = 'input[placeholder="Min"]';
   6 |         this.maxPrice = 'input[placeholder="Max"]';
   7 |         this.applyButton = 'button:has-text("Go")';
   8 |
   9 |         this.productItems = 'div[data-qa-locator="product-item"]';
  10 |         this.freeShippingLabel = 'span:has-text("Free Shipping")';
  11 |     }
  12 |
  13 |     async applyFilters() {
  14 |         // Scroll the entire page down a bit to trigger dynamic loading
  15 |         await this.page.mouse.wheel(0, 1000);
  16 |         await this.page.waitForTimeout(2000); // give time for content to appear
  17 |     
  18 |         // Wait for the brand filter section (using your provided CSS selector)
> 19 |         await this.page.waitForSelector('div._9xWFp', { timeout: 30000, state: 'visible' });
     |                         ^ Error: page.waitForSelector: Test timeout of 30000ms exceeded.
  20 |     
  21 |         // Now that the brand filter section is visible, locate the first brand filter option
  22 |         const brandOption = this.page.locator('div._9xWFp label span').first();
  23 |         await brandOption.scrollIntoViewIfNeeded();
  24 |         await brandOption.waitFor({ state: 'visible', timeout: 10000 });
  25 |         await brandOption.click();
  26 |     
  27 |         // Fill in price range fields
  28 |         await this.page.waitForSelector(this.minPrice);
  29 |         await this.page.fill(this.minPrice, '500');
  30 |     
  31 |         await this.page.waitForSelector(this.maxPrice);
  32 |         await this.page.fill(this.maxPrice, '5000');
  33 |     
  34 |         // Wait for results to refresh and apply filters
  35 |         await this.page.waitForTimeout(4000);
  36 |     }
  37 |     
  38 |
  39 |     async getProductCount() {
  40 |         const products = await this.page.$$(this.productItems);
  41 |         return products.length;
  42 |     }
  43 |
  44 |     async clickFirstProduct() {
  45 |         await this.page.locator(this.productItems).first().click();
  46 |     }
  47 |
  48 |     async isFreeShippingAvailable() {
  49 |         const freeShippingTextLocator = this.page.locator(this.freeShippingLabel);
  50 |         const isVisible = await freeShippingTextLocator.isVisible();
  51 |         console.log(`Free shipping visible: ${isVisible}`);
  52 |         return isVisible;
  53 |     }
  54 | };
  55 |
```